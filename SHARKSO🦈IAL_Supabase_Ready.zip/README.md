# SHARKSO🦈IAL Supabase Ready

1. รัน mock API: `node mock-api/index.js`
2. รัน frontend: `pnpm dev` (ภายใน client)
3. ใส่ค่า SUPABASE URL/KEY ใน `.env`